# IRremote Arduino Library
This library enables you to send and receive using infra-red signals on an arduino

## Version - 1.00

## Installation
1. Click "Download ZIP" 
2. Extract the downloaded zip file 
3. Rename the extracted folder from "Arduino-IRremote" to "IRremote"
4. Move this folder to your libraries directory

## Contributing
If you want to contribute to this project:
- Report bugs and errors
- Ask for enhancements
- Create issues and pull requests
- Tell other people about this library

## Contributors
Check [here](Contributors.md)

## Copyright
Copyright 2009-2012 Ken Shirriff
